
public class Driver {

	public static void main(String[] args) {
		
		int[] theArray = {5, 7, 2, 9, 3, 4, 12, 1};
		Sorting.selectionSort(theArray, 8);
		System.out.print("selection sort = {");
		for(int i = 0; i <= 6; i++)
		{
			System.out.print(theArray[i] + ", ");
		}
		System.out.println(theArray[7] + "}");
		
		
		
		int[] bubble = {3, 7, 1, 15, 4, 6, 11, 8};
		Sorting.oldBubbleSort(bubble, 8);
		System.out.print("old bubble = {");
		for(int i = 0; i <= 6; i++)
		{
			System.out.print(bubble[i] + ", ");
		}
		System.out.println(bubble[7] + "}");
		
		
		int[] bubble2 = {3, 7, 1, 15, 4, 6, 11, 8};
		Sorting.newbubbleSort(bubble2, 8);
		System.out.print("new bubble = {");
		for(int i = 0; i <= 6; i++)
		{
			System.out.print(bubble2[i] + ", ");
		}
		System.out.println(bubble2[7] + "}");
	}

}
