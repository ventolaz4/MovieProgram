
public class Sorting 
{
	private static final int MAXSIZE = 100;
	//sorts an array from beginning to index size-1
	//using the selection sort algorithm
	public static void  selectionSort(int theArray[], int size)
	{
		int  temp, indexSoFar;
		for(int i = 0; i < size-1; i++)
		{
			//Find index of largest element in unsorted portion
			indexSoFar = i;
			for(int j = i + 1; j < size; j++)
			{
				if (theArray[j] > theArray[indexSoFar])
					indexSoFar = j;
			}//end inner for
			//Swap the large element in unsorted portion with first in unsorted portion
			temp = theArray[i];
			theArray[i] = theArray[indexSoFar];
			theArray[indexSoFar] = temp;
		}//end outer for
	}
	
	//sorts an array from beginning to index size-1
	//using the bubble sort algorithm
	public static void  oldBubbleSort(int  theArray[], int size)
	{	
		boolean  sorted = false;
		int temp;
		long startTime = System.nanoTime();
		
		for(int  pass = 1; (pass < size)  &&  (!sorted); pass++)
		{	//assume remaining elements are already sorted
			sorted = true;
			//compare elements pairwise in unsorted portion
			for(int  index = 0; index < (size - pass); index++)
			{
				if(theArray[index] > theArray[index+1])
				{
					//swap elements
					temp = theArray[index];
					theArray[index] = theArray[index+1];
					theArray[index+1] = temp;
					//Remaining elements were not sorted
					sorted = false;
				}//end if
			}//end inner for
		}//end outer for
		System.out.println("Time taken for OLD bubbleSort: "+(System.nanoTime() - startTime));
	}//end bubbleSort
	
	public static void  newbubbleSort(int  theArray[], int size)
	{	
		boolean  sorted = false;
		int temp;
		long startTime = System.nanoTime();
		
		for(int  pass = 1; (pass < size)  &&  (!sorted); pass++)
		{	//assume remaining elements are already sorted
			sorted = true;
			int current = -1;
			for(int  index = 0; index < (size - pass); index++)
			{
				if(theArray[index] > theArray[index+1])
				{
					//swap elements
					temp = theArray[index];
					theArray[index] = theArray[index+1];
					theArray[index+1] = temp;
					//Remaining elements were not sorted
					sorted = false;
					current = pass;
				}//end if
			}//end inner for
		}//end outer for
		 System.out.println("Time taken for OPTIMIZED bubbleSort: "+(System.nanoTime() - startTime));	
	}//end bubbleSort
}
